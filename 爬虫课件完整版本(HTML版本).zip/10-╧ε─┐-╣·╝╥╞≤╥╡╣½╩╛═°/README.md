# 爬虫项目-国家企业公示网（可选）
## 介绍
根据企业名称抓取[国家企业信息公示网](http://www.gsxt.gov.cn/) 中的企业信息数据

网址：
- 主站url http://www.gsxt.gov.cn/ 
- 江苏地区url http://www.jsgsj.gov.cn:58888/province/

### 提示：该网站极其不稳定

## 内容

- 项目分析
- webapi：类flask框架quart
- node_server：节点内启动爬虫
- crawler：利用selenium进行数据抓取
- 运行效果截图

